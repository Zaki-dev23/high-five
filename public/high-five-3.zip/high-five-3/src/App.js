import React from 'react';
import Landing from './pages/landing';

function App() {
  return (
   <>
         {/* <img src={logo} className="App-logo" alt="logo" /> */}
         <Landing /> 
    </>
  );
}

export default App;
